import { useRef } from 'react'
import { Section, Card, PhotoFrame, Reveal } from './ui'
import { CASES, SAMPLE_COPY } from '../data'

function Chev({ dir }) {
  return (
    <svg viewBox="0 0 16 16" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={dir === 'l' ? 'M10 3L5 8l5 5' : 'M6 3l5 5-5 5'} />
    </svg>
  )
}

export default function Showcase() {
  const ref = useRef(null)
  const by = (dir) => {
    const el = ref.current
    if (!el) return
    const w = el.firstElementChild?.getBoundingClientRect().width || 360
    el.scrollBy({ left: dir * (w + 16), behavior: 'smooth' })
  }
  const btn =
    'flex h-11 w-11 items-center justify-center rounded-full border border-line transition-colors hover:border-accent hover:bg-accent hover:text-[#111]'

  return (
    <Section
      id="showcase"
      eyebrow="Proof, not promises"
      title="Before Sorted. After Sorted."
      className="border-t border-line"
    >
      <Reveal className="-mt-6 mb-8 flex items-center justify-between gap-4">
        <p className="text-sm text-muted">{SAMPLE_COPY ? 'Sample case studies. Swap in real ones.' : 'Real clubs. Real numbers.'}</p>
        <div className="flex gap-2">
          <button className={btn} onClick={() => by(-1)} aria-label="Previous case study">
            <Chev dir="l" />
          </button>
          <button className={btn} onClick={() => by(1)} aria-label="Next case study">
            <Chev dir="r" />
          </button>
        </div>
      </Reveal>

      <div
        ref={ref}
        tabIndex={0}
        role="region"
        aria-roledescription="carousel"
        aria-label="Case studies"
        className="no-scrollbar -mx-4 flex scroll-px-4 snap-x sm:scroll-px-6 lg:scroll-px-10 snap-mandatory gap-4 overflow-x-auto px-4 pb-4 sm:-mx-6 sm:px-6 lg:-mx-10 lg:px-10"
      >
        {CASES.map((c) => (
          <article key={c.title} className="w-[84%] shrink-0 snap-start sm:w-[420px]" aria-label={c.title}>
            <Card className="h-full">
              <PhotoFrame label={c.photo} ratio="aspect-[16/10]" />
              <div className="mt-5 flex items-center gap-2">
                <span className="rounded-full border border-line px-3 py-1 text-xs font-semibold uppercase tracking-wider text-muted">{c.tag}</span>
              </div>
              <h3 className="mt-3 font-display text-3xl font-extrabold tracking-tightest">{c.title}</h3>
              <p className="mt-2 text-muted">{c.text}</p>
              <dl className="mt-6 divide-y divide-line border-t border-line">
                {c.stats.map((s) => (
                  <div key={s.label} className="flex items-center justify-between gap-4 py-3.5">
                    <dt className="text-sm text-muted">{s.label}</dt>
                    <dd className="flex items-center gap-2.5 font-display text-xl font-bold tabular-nums">
                      <span className="text-muted line-through decoration-fg/30">
                        <span className="sr-only">Before: </span>
                        {s.before}
                      </span>
                      <svg viewBox="0 0 16 16" className="h-4 w-4 text-muted" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                        <path d="M3 8h10M9 4l4 4-4 4" />
                      </svg>
                      <span className="on-accent rounded-lg bg-accent px-2 py-0.5 text-[#111]">
                        <span className="sr-only">After: </span>
                        {s.after}
                      </span>
                    </dd>
                  </div>
                ))}
              </dl>
            </Card>
          </article>
        ))}
      </div>
    </Section>
  )
}
