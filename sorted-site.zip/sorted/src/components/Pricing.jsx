import { useEffect, useId, useState } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import { Section, Card, Reveal, Button, Arrow, cx } from './ui'
import { TIERS, BUDGETS } from '../data'

function Tier({ t }) {
  return (
    <Card className={cx('flex h-full flex-col', t.featured && 'border-fg/40')}>
      <div className="flex items-center justify-between">
        <h3 className="font-display text-3xl font-extrabold tracking-tightest">{t.name}</h3>
        {t.featured && (
          <span className="on-accent rounded-full bg-accent px-3 py-1 text-xs font-bold uppercase tracking-wider text-[#111]">
            Most picked
          </span>
        )}
      </div>
      <p className="mt-2 text-muted">{t.blurb}</p>
      <p className="mt-6 font-display text-xl font-bold">{t.price}</p>
      <ul className="mt-6 flex-1 space-y-2.5 border-t border-line pt-6 text-[15px]">
        {t.features.map((f) => (
          <li key={f} className="flex items-start gap-2.5">
            <svg viewBox="0 0 16 16" className="mt-0.5 h-4 w-4 shrink-0" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M3 8.5l3.2 3.2L13 4.5" />
            </svg>
            {f}
          </li>
        ))}
      </ul>
      <Button href="#quote" variant={t.featured ? 'primary' : 'ghost'} className="mt-8 w-full">
        Get a quote <Arrow />
      </Button>
    </Card>
  )
}

/* ---------- Field ---------- */
function Field({ label, error, children, id }) {
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-sm font-semibold">
        {label}
      </label>
      {children}
      <p id={`${id}-err`} role={error ? 'alert' : undefined} className="mt-1.5 min-h-[1.25rem] text-sm font-medium text-[#B3261E] dark:text-[#FF8A80]">
        {error || ''}
      </p>
    </div>
  )
}

const inputCls = (err) =>
  cx(
    'w-full rounded-2xl border bg-bg px-4 py-3 text-base outline-none transition-colors placeholder:text-muted/70 focus:border-fg focus:ring-2 focus:ring-accent',
    err ? 'border-[#B3261E] dark:border-[#FF8A80]' : 'border-line',
  )

const EMPTY = { club: '', college: '', email: '', need: '', budget: '', date: '' }

function validate(v) {
  const e = {}
  if (v.club.trim().length < 2) e.club = 'Tell us your club name.'
  if (v.college.trim().length < 2) e.college = 'Which college are you at?'
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email.trim())) e.email = 'Add an email so we can send the quote.'
  if (!v.need) e.need = 'Pick what you need.'
  if (!v.budget) e.budget = 'Pick a rough budget range.'
  if (!v.date) e.date = 'When do you need it by?'
  else if (v.date < new Date().toISOString().slice(0, 10)) e.date = 'That date has already passed.'
  return e
}

function QuoteForm({ presetNeed }) {
  const uid = useId()
  const reduce = useReducedMotion()
  const [v, setV] = useState({ ...EMPTY, need: presetNeed || '' })
  const [touched, setTouched] = useState({})
  const [status, setStatus] = useState('idle') // idle | sending | done
  const errors = validate(v)

  useEffect(() => {
    if (presetNeed) setV((x) => ({ ...x, need: presetNeed }))
  }, [presetNeed])

  const set = (k) => (e) => setV((x) => ({ ...x, [k]: e.target.value }))
  const blur = (k) => () => setTouched((t) => ({ ...t, [k]: true }))
  const show = (k) => (touched[k] || touched._all ? errors[k] : '')
  const idf = (k) => `${uid}-${k}`

  const onSubmit = (e) => {
    e.preventDefault()
    setTouched({ _all: true })
    const first = Object.keys(errors)[0]
    if (first) {
      document.getElementById(idf(first))?.focus()
      return
    }
    setStatus('sending')
    // TODO: POST `v` to your backend / form service here.
    setTimeout(() => setStatus('done'), 700)
  }

  const common = (k) => ({
    id: idf(k),
    value: v[k],
    onChange: set(k),
    onBlur: blur(k),
    'aria-invalid': !!show(k),
    'aria-describedby': `${idf(k)}-err`,
    className: inputCls(show(k)),
  })

  return (
    <div className="relative">
      <AnimatePresence mode="wait">
        {status === 'done' ? (
          <motion.div
            key="ok"
            role="status"
            initial={reduce ? false : { opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex min-h-[420px] flex-col items-center justify-center text-center"
          >
            <span className="on-accent flex h-16 w-16 items-center justify-center rounded-full bg-accent">
              <svg viewBox="0 0 24 24" className="h-8 w-8" fill="none" stroke="#111" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <motion.path d="M5 12.5l4.5 4.5L19 7.5" initial={reduce ? false : { pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 0.5, delay: 0.15 }} />
              </svg>
            </span>
            <h3 className="mt-6 font-display text-4xl font-extrabold tracking-tightest">Got it!</h3>
            <p className="mt-2 text-lg text-muted">We&rsquo;ll get back within 24 hours.</p>
            <button
              onClick={() => {
                setV({ ...EMPTY, need: presetNeed || '' })
                setTouched({})
                setStatus('idle')
              }}
              className="mt-6 text-sm font-semibold underline decoration-accent decoration-4 underline-offset-4"
            >
              Send another request
            </button>
          </motion.div>
        ) : (
          <motion.form key="form" noValidate onSubmit={onSubmit} exit={{ opacity: 0 }} aria-label="Get a custom quote">
            <div className="grid gap-x-5 sm:grid-cols-2">
              <Field id={idf('club')} label="Club name" error={show('club')}>
                <input {...common('club')} type="text" autoComplete="organization" placeholder="e.g. Music Society" />
              </Field>
              <Field id={idf('college')} label="College" error={show('college')}>
                <input {...common('college')} type="text" placeholder="Your college" />
              </Field>
              <div className="sm:col-span-2">
                <Field id={idf('email')} label="Email" error={show('email')}>
                  <input {...common('email')} type="email" autoComplete="email" inputMode="email" placeholder="you@college.edu" />
                </Field>
              </div>
              <Field id={idf('need')} label="What do you need?" error={show('need')}>
                <select {...common('need')}>
                  <option value="">Choose one</option>
                  <option value="merch">Merch</option>
                  <option value="events">Event logistics</option>
                  <option value="both">Both</option>
                </select>
              </Field>
              <Field id={idf('budget')} label="Budget range" error={show('budget')}>
                <select {...common('budget')}>
                  <option value="">Choose one</option>
                  {BUDGETS.map((b) => (
                    <option key={b} value={b}>
                      {b}
                    </option>
                  ))}
                </select>
              </Field>
              <div className="sm:col-span-2">
                <Field id={idf('date')} label="Date needed by" error={show('date')}>
                  <input {...common('date')} type="date" min={new Date().toISOString().slice(0, 10)} />
                </Field>
              </div>
            </div>
            <Button as="button" type="submit" disabled={status === 'sending'} className="mt-2 w-full sm:w-auto">
              {status === 'sending' ? 'Sending…' : 'Get my quote'} <Arrow />
            </Button>
          </motion.form>
        )}
      </AnimatePresence>
    </div>
  )
}

export default function Pricing({ presetNeed }) {
  return (
    <Section
      id="pricing"
      eyebrow="Pricing"
      title="Simple tiers. No surprises."
      intro="Pick the one that fits your calendar. Not sure? The quote form below sorts it out."
      className="border-t border-line"
    >
      <div className="grid gap-4 md:grid-cols-3">
        {TIERS.map((t, i) => (
          <Reveal key={t.name} delay={i * 0.07}>
            <Tier t={t} />
          </Reveal>
        ))}
      </div>

      <Reveal id="quote" className="mt-16 scroll-mt-24 grid gap-10 rounded-[28px] border border-line bg-card p-6 md:p-10 lg:grid-cols-5 lg:gap-14">
        <div className="lg:col-span-2">
          <p className="eyebrow mb-4">Custom quote</p>
          <h3 className="font-display text-4xl font-extrabold leading-[1.02] tracking-tightest md:text-5xl">
            Stop chasing vendors.
          </h3>
          <p className="mt-4 text-lg text-muted">Five fields, two minutes. Your quote lands within 24 hours.</p>
        </div>
        <div className="lg:col-span-3">
          <QuoteForm presetNeed={presetNeed} />
        </div>
      </Reveal>
    </Section>
  )
}
