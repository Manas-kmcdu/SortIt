import { Section, Card, Reveal } from './ui'
import { TESTIMONIALS, SAMPLE_COPY } from '../data'

export default function Testimonials() {
  return (
    <Section
      id="testimonials"
      eyebrow="Straight from club presidents"
      title="They stopped chasing. They started doing."
      className="border-t border-line"
    >
      <div className="grid gap-4 md:grid-cols-3">
        {TESTIMONIALS.map((t, i) => (
          <Reveal key={i} delay={i * 0.07}>
            <Card as="figure" className="flex h-full flex-col">
              <svg viewBox="0 0 32 24" className="h-6 w-8" aria-hidden="true">
                <path d="M0 24V13.5C0 6 4 1.5 11 0l1.5 3.2C8.5 4.6 6.800 7 6.600 10H12v14H0zm18 0V13.500C18 6 22 1.500 29 0l1.500 3.200C26.500 4.600 24.800 7 24.600 10H30v14H18z" fill="rgb(198 244 50)" stroke="rgb(17 17 17 / .25)" />
              </svg>
              <blockquote className="mt-5 flex-1 font-display text-2xl font-bold leading-snug tracking-tight">
                {t.quote}
              </blockquote>
              <figcaption className="mt-8 border-t border-line pt-4 text-sm">
                <p className="font-semibold">{t.name}</p>
                <p className="text-muted">
                  {t.role}, {t.college}
                </p>
              </figcaption>
            </Card>
          </Reveal>
        ))}
      </div>
      {SAMPLE_COPY && <p className="mt-6 text-xs text-muted">Sample quotes. Replace with real ones (with permission) before launch.</p>}
    </Section>
  )
}
