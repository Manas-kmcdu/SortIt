import { useState } from 'react'
import { motion, useReducedMotion } from 'framer-motion'
import { Section, Card, Reveal, cx } from './ui'

function Title({ k, children, sub }) {
  return (
    <div>
      <p className="eyebrow mb-2">{k}</p>
      <h3 className="font-display text-2xl font-extrabold leading-tight tracking-tightest md:text-3xl">{children}</h3>
      {sub && <p className="mt-2 text-[15px] text-muted">{sub}</p>}
    </div>
  )
}

function Quotes() {
  const [picked, setPicked] = useState(null)
  const rows = [
    ['Sound & lights', 'Vendor A', 41200],
    ['Sound & lights', 'Vendor B', 38000],
    ['Sound & lights', 'Vendor C', 44500],
  ]
  return (
    <>
      <Title k="Vendor quotes" sub="Compare, haggle-free, approve. Quotes in 24 hours.">
        One-tap vendor quotes.
      </Title>
      <ul className="mt-8 space-y-2">
        {rows.map(([item, v, p], i) => {
          const best = p === 38000
          const on = picked === i
          return (
            <li
              key={v}
              className={cx(
                'on-accent flex items-center justify-between gap-3 rounded-2xl border px-4 py-3 text-sm transition-colors',
                on ? 'border-accent bg-accent text-[#111]' : 'border-line bg-fg/[0.03]',
              )}
            >
              <div>
                <p className="font-semibold">{v}</p>
                <p className={on ? 'text-[#111]/70' : 'text-muted'}>
                  {item}
                  {best ? ' · best price' : ''}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-semibold tabular-nums">₹{p.toLocaleString('en-IN')}</span>
                <button
                  onClick={() => setPicked(on ? null : i)}
                  aria-pressed={on}
                  className={cx(
                    'rounded-full px-3.5 py-1.5 text-xs font-semibold transition-colors',
                    on ? 'bg-[#111] text-white' : 'border border-fg/25 hover:bg-accent hover:text-[#111]',
                  )}
                >
                  {on ? 'Approved' : 'Approve'}
                </button>
              </div>
            </li>
          )
        })}
      </ul>
      <div className="mt-auto pt-8">
        <div className="flex items-center justify-between rounded-2xl border border-dashed border-fg/25 px-4 py-3 text-sm">
          <span className="text-muted">Best vs highest quote</span>
          <span className="font-display text-lg font-extrabold tabular-nums tracking-tight">₹6,500 saved</span>
        </div>
      </div>
    </>
  )
}

function Budget() {
  const reduce = useReducedMotion()
  return (
    <>
      <Title k="Budget tracker" sub="See every rupee as it moves.">
        Budget that tells the truth.
      </Title>
      <div className="mt-8">
        <div className="mb-2 flex justify-between text-sm">
          <span className="text-muted">Spent</span>
          <span className="font-semibold tabular-nums">₹81,600 of ₹1,20,000</span>
        </div>
        <div className="h-3 overflow-hidden rounded-full bg-fg/10" role="img" aria-label="68 percent of budget spent">
          <motion.div
            className="h-full rounded-full bg-accent ring-1 ring-inset ring-fg/20"
            initial={reduce ? false : { width: 0 }}
            whileInView={{ width: '68%' }}
            viewport={{ once: true }}
            transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
            style={reduce ? { width: '68%' } : undefined}
          />
        </div>
        <ul className="mt-5 grid grid-cols-3 gap-3 text-sm">
          {[['Stage', '₹38k'], ['Merch', '₹29k'], ['Print', '₹14k']].map(([a, b]) => (
            <li key={a} className="rounded-xl bg-fg/[0.04] px-3 py-2">
              <p className="text-muted">{a}</p>
              <p className="font-semibold tabular-nums">{b}</p>
            </li>
          ))}
        </ul>
      </div>
    </>
  )
}

function Checklist() {
  const [done, setDone] = useState([true, true, false, false])
  const items = ['Hall confirmed', 'Mics tested', 'Gate crew briefed', 'Banners up']
  return (
    <>
      <Title k="Event-day checklist">Day-of, handled.</Title>
      <ul className="mt-6 space-y-2">
        {items.map((t, i) => (
          <li key={t}>
            <label className="flex cursor-pointer items-center gap-3 text-sm">
              <input
                type="checkbox"
                checked={done[i]}
                onChange={() => setDone((d) => d.map((x, j) => (j === i ? !x : x)))}
                className="peer sr-only"
              />
              <span
                aria-hidden="true"
                className="on-accent flex h-5 w-5 shrink-0 items-center justify-center rounded-md border border-fg/30 peer-checked:border-accent peer-checked:bg-accent peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2"
              >
                {done[i] && (
                  <svg viewBox="0 0 16 16" className="h-3 w-3" fill="none" stroke="#111" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M3.5 8.5l3 3 6-6.5" />
                  </svg>
                )}
              </span>
              <span className={done[i] ? 'text-muted line-through decoration-fg/30' : ''}>{t}</span>
            </label>
          </li>
        ))}
      </ul>
    </>
  )
}

function Studio() {
  const swatches = [
    ['Black', '#111111'],
    ['Stone', '#D9D8D2'],
    ['Grey', '#7B7B76'],
  ]
  const [c, setC] = useState(0)
  return (
    <>
      <Title k="Design studio">Merch, mocked up.</Title>
      <div className="mt-4 flex items-center justify-between gap-4">
        <svg viewBox="0 0 140 140" className="h-24 w-24 shrink-0 transition-all" role="img" aria-label={`Tee preview in ${swatches[c][0]}`}>
          <path d="M30 20L50 10Q60 24 70 24Q80 24 90 10L110 20L130 48L108 58L100 50V128H40V50L32 58L10 48Z" fill={swatches[c][1]} style={{ stroke: 'rgb(var(--fg) / 0.3)' }} />
          <rect x="52" y="58" width="36" height="26" rx="4" fill="rgb(198 244 50)" />
          <path d="M58 68h24M58 75h14" stroke="#111" strokeWidth="3" strokeLinecap="round" />
        </svg>
        <div role="radiogroup" aria-label="Tee colour" className="flex flex-col gap-2">
          {swatches.map(([name, hex], i) => (
            <button
              key={name}
              role="radio"
              aria-checked={c === i}
              aria-label={name}
              onClick={() => setC(i)}
              className={cx('h-7 w-7 rounded-full border-2 transition-transform hover:scale-110', c === i ? 'border-fg' : 'border-line')}
              style={{ background: hex }}
            />
          ))}
        </div>
      </div>
    </>
  )
}

function Split() {
  const people = [['A', true], ['R', true], ['S', true], ['K', false]]
  return (
    <>
      <Title k="Payment splitting" sub="Everyone pays their share. Nobody chases anybody.">
        Split it with the committee.
      </Title>
      <div className="mt-6 flex items-center justify-between gap-4">
        <ul className="flex -space-x-2" aria-label="Committee payment status">
          {people.map(([n, paid]) => (
            <li
              key={n}
              className={cx(
                'on-accent flex h-11 w-11 items-center justify-center rounded-full border-2 border-card text-sm font-bold',
                paid ? 'bg-accent text-[#111]' : 'bg-fg/10 text-muted',
              )}
            >
              {n}
              <span className="sr-only">{paid ? ' paid' : ' pending'}</span>
            </li>
          ))}
        </ul>
        <div className="text-right">
          <p className="font-display text-2xl font-extrabold tabular-nums tracking-tightest">₹2,500</p>
          <p className="text-xs text-muted">each · 3 of 4 paid</p>
        </div>
      </div>
    </>
  )
}

function Report() {
  const bars = [38, 62, 48, 90, 74, 56]
  const reduce = useReducedMotion()
  return (
    <>
      <Title k="Post-event report" sub="The report your college asks for, ready when the lights go off.">
        Reports in one click.
      </Title>
      <div className="mt-6 flex items-end justify-between gap-6">
        <div className="flex h-20 flex-1 items-end gap-2" role="img" aria-label="Attendance by hour, peaking in the evening">
          {bars.map((h, i) => (
            <motion.div
              key={i}
              className={cx('flex-1 rounded-t-md', i === 3 ? 'bg-accent ring-1 ring-fg/20' : 'bg-fg/15')}
              initial={reduce ? false : { height: 0 }}
              whileInView={{ height: `${h}%` }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: i * 0.07, ease: [0.22, 1, 0.36, 1] }}
            />
          ))}
        </div>
        <span className="rounded-full border border-line px-3.5 py-1.5 text-xs font-semibold">Download PDF</span>
      </div>
    </>
  )
}

export default function Bento() {
  return (
    <Section
      id="features"
      eyebrow="Inside the dashboard"
      title="Everything in one place."
      intro="Built by people who have stacked the chairs themselves."
      className="border-t border-line"
    >
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[
          [Quotes, 'md:col-span-2 lg:row-span-2'],
          [Budget, 'md:col-span-2'],
          [Checklist, ''],
          [Studio, ''],
          [Split, 'lg:col-span-2'],
          [Report, 'lg:col-span-2'],
        ].map(([C, cls], i) => (
          <Reveal key={i} delay={(i % 3) * 0.06} className={cx('flex', cls)}>
            <Card className="flex w-full flex-col">
              <C />
            </Card>
          </Reveal>
        ))}
      </div>
    </Section>
  )
}
