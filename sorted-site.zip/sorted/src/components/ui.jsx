import { useRef, useState, useEffect, useId } from 'react'
import {
  motion,
  AnimatePresence,
  useMotionValue,
  useSpring,
  useInView,
  animate,
  useReducedMotion,
} from 'framer-motion'

export const cx = (...a) => a.filter(Boolean).join(' ')

export function Arrow({ className = 'h-4 w-4' }) {
  return (
    <svg
      className={cx('transition-transform duration-200 group-hover:translate-x-0.5', className)}
      viewBox="0 0 16 16"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M3 8h10M9 4l4 4-4 4" />
    </svg>
  )
}

/* ---------- Button (magnetic hover) ---------- */
const VARIANTS = {
  primary: 'on-accent bg-accent text-[#111] hover:shadow-lift',
  dark: 'bg-fg text-bg hover:bg-accent hover:text-[#111]',
  ghost: 'border border-fg/20 text-fg hover:border-accent hover:bg-accent hover:text-[#111]',
}

export function Button({ as = 'a', variant = 'primary', magnetic = true, className, children, ...props }) {
  const reduce = useReducedMotion()
  const ref = useRef(null)
  const x = useMotionValue(0)
  const y = useMotionValue(0)
  const sx = useSpring(x, { stiffness: 220, damping: 16, mass: 0.4 })
  const sy = useSpring(y, { stiffness: 220, damping: 16, mass: 0.4 })
  const Tag = motion[as]

  const onMove = (e) => {
    if (reduce || !magnetic || e.pointerType === 'touch' || !ref.current) return
    const r = ref.current.getBoundingClientRect()
    x.set((e.clientX - (r.left + r.width / 2)) * 0.22)
    y.set((e.clientY - (r.top + r.height / 2)) * 0.3)
  }
  const onLeave = () => {
    x.set(0)
    y.set(0)
  }

  return (
    <Tag
      ref={ref}
      onPointerMove={onMove}
      onPointerLeave={onLeave}
      style={{ x: sx, y: sy }}
      className={cx(
        'group relative inline-flex select-none items-center justify-center gap-2 rounded-full px-6 py-3.5 text-[15px] font-semibold transition-[colors,box-shadow] duration-200',
        VARIANTS[variant],
        className,
      )}
      {...props}
    >
      {children}
    </Tag>
  )
}

/* ---------- Reveal (scroll-triggered fade / slide-up) ---------- */
export function Reveal({ children, delay = 0, y = 24, className, as = 'div', ...rest }) {
  const reduce = useReducedMotion()
  const M = motion[as]
  return (
    <M
      className={className}
      initial={reduce ? false : { opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-80px' }}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
      {...rest}
    >
      {children}
    </M>
  )
}

/* ---------- Section ---------- */
export function Section({ id, eyebrow, title, intro, children, className, headerClass }) {
  return (
    <section id={id} className={cx('scroll-mt-20 py-20 md:py-28', className)}>
      <div className="container-x">
        {(eyebrow || title) && (
          <Reveal className={cx('mb-12 max-w-3xl md:mb-16', headerClass)}>
            {eyebrow && <p className="eyebrow mb-4">{eyebrow}</p>}
            {title && (
              <h2
                className="font-display font-extrabold leading-[1] tracking-tightest"
                style={{ fontSize: 'clamp(36px, 5.2vw, 68px)' }}
              >
                {title}
              </h2>
            )}
            {intro && <p className="mt-5 max-w-xl text-lg text-muted">{intro}</p>}
          </Reveal>
        )}
        {children}
      </div>
    </section>
  )
}

/* ---------- Card (lift + accent underline on hover) ---------- */
export function Card({ children, className, as: Tag = 'div', ...props }) {
  return (
    <Tag
      className={cx(
        'group relative overflow-hidden rounded-3xl border border-line bg-card p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-lift md:p-7',
        className,
      )}
      {...props}
    >
      {children}
      <span
        aria-hidden="true"
        className="absolute bottom-0 left-0 h-[3px] w-0 bg-accent transition-all duration-500 group-hover:w-full"
      />
    </Tag>
  )
}

/* ---------- Photo placeholder frame (swap for a lazy-loaded <img>) ---------- */
export function PhotoFrame({ label, className, ratio = 'aspect-[4/3]' }) {
  return (
    <div
      role="img"
      aria-label={`Placeholder photo: ${label}`}
      className={cx('ph relative overflow-hidden rounded-2xl border border-line', ratio, className)}
    >
      <span className="absolute bottom-3 left-3 inline-flex items-center gap-1.5 rounded-full bg-card/90 px-3 py-1.5 text-xs font-medium text-muted backdrop-blur">
        <svg viewBox="0 0 16 16" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
          <rect x="1.5" y="3.5" width="13" height="10" rx="2" />
          <circle cx="8" cy="8.5" r="2.5" />
          <path d="M5.5 3.5l.8-1.5h3.4l.8 1.5" />
        </svg>
        {label}
      </span>
    </div>
  )
}

/* ---------- Marquee ---------- */
export function Marquee({ items }) {
  const row = (hidden) => (
    <ul className="flex shrink-0 items-center gap-3 pr-3" aria-hidden={hidden || undefined}>
      {items.map((i) => (
        <li
          key={i}
          className="whitespace-nowrap rounded-full border border-line bg-card px-5 py-2.5 text-sm font-medium"
        >
          {i}
        </li>
      ))}
    </ul>
  )
  return (
    <div className="marquee relative overflow-hidden" role="group" aria-label="Types of clubs we work with">
      <div className="marquee-track flex w-max">
        {row(false)}
        {row(true)}
      </div>
    </div>
  )
}

/* ---------- Stat (animated counter) ---------- */
export function Stat({ value, suffix = '', prefix = '', label }) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-60px' })
  const reduce = useReducedMotion()
  const [n, setN] = useState(0)

  useEffect(() => {
    if (!inView) return
    if (reduce) {
      setN(value)
      return
    }
    const controls = animate(0, value, {
      duration: 1.6,
      ease: [0.22, 1, 0.36, 1],
      onUpdate: (v) => setN(Math.round(v)),
    })
    return () => controls.stop()
  }, [inView, value, reduce])

  return (
    <div ref={ref}>
      <div
        className="font-display text-5xl font-extrabold tabular-nums tracking-tightest md:text-6xl"
        aria-label={`${prefix}${value}${suffix} ${label}`}
      >
        <span aria-hidden="true">
          {prefix}
          {n}
          {suffix}
        </span>
      </div>
      <p className="mt-1 text-sm text-muted" aria-hidden="true">
        {label}
      </p>
    </div>
  )
}

/* ---------- Accordion ---------- */
export function Accordion({ items }) {
  const [open, setOpen] = useState(0)
  const id = useId()
  const reduce = useReducedMotion()

  return (
    <div className="divide-y divide-line border-y border-line">
      {items.map((it, i) => {
        const isOpen = open === i
        return (
          <div key={it.q}>
            <h3>
              <button
                id={`${id}-b${i}`}
                aria-expanded={isOpen}
                aria-controls={`${id}-p${i}`}
                onClick={() => setOpen(isOpen ? -1 : i)}
                className="group flex w-full items-center justify-between gap-6 py-6 text-left font-display text-xl font-bold tracking-tight md:text-2xl"
              >
                <span className="transition-colors group-hover:underline group-hover:decoration-accent group-hover:decoration-4 group-hover:underline-offset-4">
                  {it.q}
                </span>
                <span
                  aria-hidden="true"
                  className={cx(
                    'flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-line transition-all duration-300',
                    isOpen ? 'on-accent rotate-45 border-accent bg-accent text-[#111]' : 'group-hover:bg-accent group-hover:text-[#111]',
                  )}
                >
                  <svg viewBox="0 0 16 16" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                    <path d="M8 3v10M3 8h10" />
                  </svg>
                </span>
              </button>
            </h3>
            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  id={`${id}-p${i}`}
                  role="region"
                  aria-labelledby={`${id}-b${i}`}
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: reduce ? 0 : 0.3, ease: [0.22, 1, 0.36, 1] }}
                  className="overflow-hidden"
                >
                  <p className="max-w-2xl pb-6 pr-12 text-lg text-muted">{it.a}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )
      })}
    </div>
  )
}
