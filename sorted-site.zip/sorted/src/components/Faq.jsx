import { Section, Accordion, Reveal } from './ui'
import { FAQS } from '../data'

export default function Faq() {
  return (
    <Section id="faq" className="border-t border-line">
      <div className="grid gap-10 lg:grid-cols-12">
        <Reveal className="lg:col-span-4">
          <p className="eyebrow mb-4">FAQ</p>
          <h2 className="font-display font-extrabold leading-[1] tracking-tightest" style={{ fontSize: 'clamp(36px, 5.2vw, 68px)' }}>
            Quick answers.
          </h2>
          <p className="mt-5 max-w-sm text-lg text-muted">
            Still stuck? Email us and a human (probably a senior) will reply.
          </p>
        </Reveal>
        <Reveal className="lg:col-span-8" delay={0.05}>
          <Accordion items={FAQS} />
        </Reveal>
      </div>
    </Section>
  )
}
