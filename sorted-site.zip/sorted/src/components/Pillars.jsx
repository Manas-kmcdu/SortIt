import { motion } from 'framer-motion'
import { Section, Reveal, PhotoFrame, Arrow, cx } from './ui'
import { PILLARS, NEEDS } from '../data'

function Pillar({ p, dim }) {
  return (
    <motion.article
      animate={{ opacity: dim ? 0.45 : 1, scale: dim ? 0.985 : 1 }}
      transition={{ duration: 0.4 }}
      className={cx(
        'group relative flex flex-col overflow-hidden rounded-3xl border bg-card p-6 transition-colors duration-300 md:p-8',
        dim ? 'border-line' : 'border-fg/30',
      )}
    >
      <div className="flex items-center justify-between">
        <span className="on-accent rounded-full bg-accent px-3 py-1 text-xs font-bold uppercase tracking-wider text-[#111]">
          {p.tag}
        </span>
      </div>
      <h3 className="mt-6 font-display text-3xl font-extrabold leading-[1.05] tracking-tightest md:text-4xl">{p.title}</h3>
      <p className="mt-3 max-w-md text-muted">{p.text}</p>

      <PhotoFrame label={p.photo} className="mt-6" ratio="aspect-[16/10]" />

      <ul className="mt-6 flex flex-wrap gap-2">
        {p.list.map((i) => (
          <li key={i} className="rounded-full border border-line px-3.5 py-1.5 text-sm font-medium">
            {i}
          </li>
        ))}
      </ul>

      <ul className="mt-6 grid grid-cols-2 gap-x-4 gap-y-2 border-t border-line pt-6 text-sm">
        {p.perks.map((perk) => (
          <li key={perk} className="flex items-center gap-2">
            <svg viewBox="0 0 16 16" className="h-4 w-4 shrink-0" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M3 8.5l3.2 3.2L13 4.5" />
            </svg>
            {perk}
          </li>
        ))}
      </ul>

      <a href="#quote" className="mt-8 inline-flex items-center gap-2 self-start text-[15px] font-semibold underline decoration-accent decoration-4 underline-offset-4 hover:decoration-fg">
        {p.id === 'merch' ? 'Get a merch quote' : 'Get an event quote'} <Arrow />
      </a>
    </motion.article>
  )
}

export default function Pillars({ need }) {
  const label = NEEDS.find((n) => n.id === need)?.label
  return (
    <Section
      id="what-we-do"
      eyebrow="What we do"
      title="Two things. Done properly."
      intro="Your club has enough to worry about. Merch and events are on us."
    >
      <Reveal className="mb-6 flex items-center gap-2 text-sm text-muted" aria-live="polite">
        <span className="inline-block h-2 w-2 rounded-full bg-accent ring-1 ring-fg/30" aria-hidden="true" />
        Showing what matters for: <strong className="text-fg">{label}</strong>
      </Reveal>
      <Reveal className="grid gap-5 md:grid-cols-2" delay={0.05}>
        <Pillar p={PILLARS.merch} dim={need === 'events'} />
        <Pillar p={PILLARS.events} dim={need === 'merch'} />
      </Reveal>
    </Section>
  )
}
