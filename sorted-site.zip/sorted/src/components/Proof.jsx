import { Reveal, Stat, Marquee } from './ui'
import { STATS, CLUBS, SAMPLE_COPY } from '../data'

export default function Proof() {
  return (
    <section aria-label="Social proof" className="border-y border-line py-14 md:py-20">
      <div className="container-x">
        <Reveal>
          <p className="eyebrow mb-5">Trusted by clubs at</p>
          {/* Replace these with real college logos (as <img alt="..."> inside the li) */}
          <ul className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {['College logo', 'College logo', 'College logo', 'College logo'].map((t, i) => (
              <li
                key={i}
                className="flex h-14 items-center justify-center rounded-2xl border border-dashed border-fg/20 text-sm text-muted"
              >
                {t}
              </li>
            ))}
          </ul>
        </Reveal>

        <Reveal className="mt-14 grid grid-cols-1 gap-10 sm:grid-cols-3" delay={0.05}>
          {STATS.map((s) => (
            <Stat key={s.label} {...s} />
          ))}
        </Reveal>
        {SAMPLE_COPY && <p className="mt-6 text-xs text-muted">Sample figures. Replace with real numbers before launch.</p>}
      </div>

      <Reveal className="mt-14">
        <Marquee items={CLUBS} />
      </Reveal>
    </section>
  )
}
