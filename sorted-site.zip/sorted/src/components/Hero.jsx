import { useRef, useState } from 'react'
import { motion, AnimatePresence, useScroll, useTransform, useReducedMotion } from 'framer-motion'
import { Button, Arrow, cx } from './ui'
import { NEEDS, FEATURED } from '../data'

const WORDS = ['Your', 'club', 'runs', 'on', 'passion.', 'Everything', 'else?']
const EASE = [0.22, 1, 0.36, 1]

function CheckBadge({ reduce, delay }) {
  return (
    <span
      aria-hidden="true"
      className="on-accent ml-[0.1em] inline-flex h-[0.36em] w-[0.36em] -translate-y-[0.62em] items-center justify-center rounded-full bg-accent align-baseline"
    >
      <svg viewBox="0 0 24 24" className="h-[62%] w-[62%]" fill="none" stroke="#111" strokeWidth="3.4" strokeLinecap="round" strokeLinejoin="round">
        <motion.path
          d="M5 12.5l4.5 4.5L19 7.5"
          initial={reduce ? false : { pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.5, delay, ease: 'easeOut' }}
        />
      </svg>
    </span>
  )
}

function Headline({ reduce }) {
  const word = (w, i, extra) => (
    <span key={w} className="inline-block overflow-hidden pb-[0.1em] align-bottom" aria-hidden="true">
      <motion.span
        className={cx('inline-block', extra)}
        initial={reduce ? false : { y: '110%' }}
        animate={{ y: 0 }}
        transition={{ duration: 0.75, delay: 0.1 + i * 0.08, ease: EASE }}
      >
        {w}
      </motion.span>
    </span>
  )
  const lastDelay = 0.1 + WORDS.length * 0.08
  return (
    <h1
      aria-label="Your club runs on passion. Everything else? Sorted."
      className="font-display font-extrabold leading-[0.95] tracking-tightest"
      style={{ fontSize: 'clamp(56px, 9.4vw, 120px)' }}
    >
      {WORDS.map((w, i) => (
        <span key={w}>
          {word(w, i)}{' '}
        </span>
      ))}
      <span className="whitespace-nowrap">
        {word('Sorted.', WORDS.length, 'hl')}
        <CheckBadge reduce={reduce} delay={lastDelay + 0.55} />
      </span>
    </h1>
  )
}

/* ---------- "Sort my club" ---------- */
function SortPicker({ need, onChange }) {
  const onKey = (e) => {
    const i = NEEDS.findIndex((n) => n.id === need)
    let next = null
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown') next = NEEDS[(i + 1) % NEEDS.length]
    if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') next = NEEDS[(i - 1 + NEEDS.length) % NEEDS.length]
    if (next) {
      e.preventDefault()
      onChange(next.id)
      requestAnimationFrame(() => document.getElementById(`need-${next.id}`)?.focus())
    }
  }
  return (
    <div>
      <p id="sort-label" className="eyebrow mb-3">
        Sort my club. What do you need?
      </p>
      <div
        role="radiogroup"
        aria-labelledby="sort-label"
        onKeyDown={onKey}
        className="relative inline-flex rounded-full border border-line bg-card p-1"
      >
        {NEEDS.map((n) => {
          const active = need === n.id
          return (
            <button
              key={n.id}
              id={`need-${n.id}`}
              role="radio"
              aria-checked={active}
              tabIndex={active ? 0 : -1}
              onClick={() => onChange(n.id)}
              className={cx(
                'relative rounded-full px-5 py-2.5 text-[15px] font-semibold transition-colors sm:px-7',
                active ? 'text-[#111]' : 'text-muted hover:text-fg',
              )}
            >
              {active && (
                <motion.span
                  layoutId="need-pill"
                  className="absolute inset-0 rounded-full bg-accent"
                  transition={{ type: 'spring', stiffness: 380, damping: 32 }}
                />
              )}
              <span className="relative">{n.label}</span>
            </button>
          )
        })}
      </div>
    </div>
  )
}

function Featured({ need }) {
  const f = FEATURED[need]
  return (
    <div className="min-h-[104px]" aria-live="polite">
      <AnimatePresence mode="wait">
        <motion.div
          key={need}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -6 }}
          transition={{ duration: 0.25 }}
        >
          <p className="max-w-md text-[15px] text-muted">{f.line}</p>
          <ul className="mt-3 flex flex-wrap gap-2">
            {f.items.map((it) => (
              <li key={it} className="rounded-full border border-line bg-card px-3.5 py-1.5 text-sm font-medium">
                {it}
              </li>
            ))}
          </ul>
        </motion.div>
      </AnimatePresence>
    </div>
  )
}

/* ---------- Collage cards ---------- */
function Tee({ fill = 'currentColor', className }) {
  return (
    <svg viewBox="0 0 140 140" className={className} aria-hidden="true">
      <path
        d="M30 20L50 10Q60 24 70 24Q80 24 90 10L110 20L130 48L108 58L100 50V128H40V50L32 58L10 48Z"
        fill={fill}
      />
      <rect x="52" y="58" width="36" height="26" rx="4" fill="rgb(198 244 50)" />
      <path d="M58 68h24M58 75h14" stroke="#111" strokeWidth="3" strokeLinecap="round" />
    </svg>
  )
}

function MerchCard() {
  return (
    <div className="rounded-3xl border border-line bg-card p-4">
      <div className="ph flex aspect-[5/4] items-center justify-center rounded-2xl text-fg">
        <Tee className="h-[78%]" />
      </div>
      <div className="mt-3 flex items-center justify-between gap-2">
        <div>
          <p className="text-sm font-semibold">Society tee drop</p>
          <p className="text-xs text-muted">150 pcs · S to XXL</p>
        </div>
        <span className="on-accent whitespace-nowrap rounded-full bg-accent px-2.5 py-1 text-xs font-semibold text-[#111]">In print</span>
      </div>
    </div>
  )
}

function ChecklistCard() {
  const rows = [
    ['Hall booked', true],
    ['Sound & lights', true],
    ['Security briefed', true],
    ['Posters printed', false],
  ]
  return (
    <div className="rounded-3xl border border-line bg-card p-4">
      <div className="mb-3 flex items-center justify-between">
        <p className="text-sm font-semibold">Fest day checklist</p>
        <p className="text-xs text-muted">3 of 4</p>
      </div>
      <ul className="space-y-2">
        {rows.map(([t, done], i) => (
          <li key={t} className="flex items-center gap-2.5 text-sm">
            <span
              aria-hidden="true"
              className={cx(
                'on-accent flex h-5 w-5 items-center justify-center rounded-md border',
                done ? 'border-accent bg-accent' : 'border-fg/25',
              )}
            >
              {done && (
                <svg viewBox="0 0 16 16" className="h-3 w-3" fill="none" stroke="#111" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M3.5 8.5l3 3 6-6.5" />
                </svg>
              )}
            </span>
            <span className={done ? 'text-muted line-through decoration-fg/30' : ''}>{t}</span>
            <span className="sr-only">{done ? 'done' : 'to do'}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}

function QuoteCard() {
  const q = [
    ['Vendor A', '₹41,200', false],
    ['Vendor B', '₹38,000', true],
    ['Vendor C', '₹44,500', false],
  ]
  return (
    <div className="rounded-3xl border border-line bg-card p-4">
      <div className="mb-3 flex items-center justify-between">
        <p className="text-sm font-semibold">Sound & lights</p>
        <p className="whitespace-nowrap text-xs text-muted">3 quotes</p>
      </div>
      <ul className="space-y-1.5">
        {q.map(([v, p, best]) => (
          <li
            key={v}
            className={cx(
              'on-accent flex items-center justify-between rounded-xl px-3 py-2 text-sm',
              best ? 'bg-accent font-semibold text-[#111]' : 'bg-fg/[0.04]',
            )}
          >
            <span>{v}</span>
            <span className="tabular-nums">
              {p}
              {best && <span className="ml-2 text-xs font-semibold">Best</span>}
            </span>
          </li>
        ))}
      </ul>
    </div>
  )
}

function Collage({ heroRef, reduce }) {
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] })
  const yA = useTransform(scrollYProgress, [0, 1], [0, -70])
  const yB = useTransform(scrollYProgress, [0, 1], [0, 40])
  const yC = useTransform(scrollYProgress, [0, 1], [0, -130])
  const rA = useTransform(scrollYProgress, [0, 1], [3, 7])
  const rB = useTransform(scrollYProgress, [0, 1], [-3, -6])
  const rC = useTransform(scrollYProgress, [0, 1], [2, -2])
  const m = (y, r) => (reduce ? {} : { y, rotate: r })

  const enter = (d) => ({
    initial: reduce ? false : { opacity: 0, y: 40 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.8, delay: 0.5 + d, ease: EASE },
  })

  return (
    <div className="relative mx-auto h-[580px] w-full max-w-[460px] lg:ml-auto" aria-hidden="true">
      <motion.div style={m(yA, rA)} className="absolute right-0 top-0 w-[200px] sm:w-[250px]">
        <motion.div {...enter(0)}>
          <MerchCard />
        </motion.div>
      </motion.div>
      <motion.div style={m(yB, rB)} className="absolute left-0 top-[245px] w-[215px] sm:top-[255px] sm:w-[260px]">
        <motion.div {...enter(0.12)}>
          <ChecklistCard />
        </motion.div>
      </motion.div>
      <motion.div style={m(yC, rC)} className="absolute bottom-0 right-0 w-[225px] sm:w-[270px]">
        <motion.div {...enter(0.24)}>
          <QuoteCard />
        </motion.div>
      </motion.div>
    </div>
  )
}

export default function Hero({ need, onNeedChange, onCta }) {
  const ref = useRef(null)
  const reduce = useReducedMotion()

  return (
    <section id="top" ref={ref} className="relative overflow-hidden pb-16 pt-32 md:pb-24 md:pt-40">
      <div className="container-x">
        <motion.p
          initial={reduce ? false : { opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="eyebrow mb-6"
        >
          For club heads, committees &amp; fest teams
        </motion.p>

        <Headline reduce={reduce} />

        <div className="mt-10 grid gap-14 lg:grid-cols-12 lg:items-start">
        <div className="lg:col-span-7">
          <motion.div
            initial={reduce ? false : { opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 1.1, ease: EASE }}
          >
            <p className="max-w-xl text-xl text-muted">
              Clubs run on passion. We sort the rest: merch, events, vendors, permissions and payments.
            </p>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Button href="#quote" onClick={() => onCta('merch')}>
                Start your club&rsquo;s order <Arrow />
              </Button>
              <Button href="#quote" variant="ghost" onClick={() => onCta('events')}>
                Plan an event <Arrow />
              </Button>
            </div>

            <div className="mt-12 space-y-5 border-t border-line pt-8">
              <SortPicker need={need} onChange={onNeedChange} />
              <Featured need={need} />
            </div>
          </motion.div>
        </div>

        <div className="lg:col-span-5">
          <Collage heroRef={ref} reduce={reduce} />
        </div>
        </div>
      </div>
    </section>
  )
}
