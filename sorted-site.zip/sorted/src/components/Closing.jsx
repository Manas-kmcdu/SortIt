import { Button, Arrow, Reveal } from './ui'
import { Wordmark } from './Nav'
import { NAV_LINKS } from '../data'

export function FinalCTA() {
  return (
    <section aria-labelledby="final-cta" className="px-3 pb-6 sm:px-4 md:pb-10">
      <Reveal className="on-accent mx-auto max-w-[1280px] rounded-[28px] bg-accent px-6 py-20 text-[#111] md:rounded-[40px] md:px-16 md:py-32">
        <h2
          id="final-cta"
          className="max-w-4xl font-display font-extrabold leading-[0.95] tracking-tightest"
          style={{ fontSize: 'clamp(48px, 8vw, 112px)' }}
        >
          Stop chasing vendors. Get Sorted.
        </h2>
        <div className="mt-10 flex flex-col gap-3 sm:flex-row sm:items-center">
          <Button href="#quote" variant="dark" className="!bg-[#111] !text-white hover:!bg-white hover:!text-[#111]">
            Get Sorted <Arrow />
          </Button>
          <p className="text-lg font-medium text-[#111]/75">Quote in 24 hours. No WhatsApp group required.</p>
        </div>
      </Reveal>
    </section>
  )
}

const SOCIALS = [
  { label: 'Instagram', href: '#', d: 'M7 3h10a4 4 0 014 4v10a4 4 0 01-4 4H7a4 4 0 01-4-4V7a4 4 0 014-4zm5 5a4 4 0 100 8 4 4 0 000-8zm5.2-1.7a.9.9 0 100 1.800.9.9 0 000-1.800z' },
  { label: 'LinkedIn', href: '#', d: 'M4.500 9h3.500v11H4.500zM6.250 3.500a2 2 0 110 4 2 2 0 010-4zM10 9h3.300v1.500c.5-.9 1.700-1.800 3.400-1.800 3.500 0 4.300 2.300 4.300 5.300V20h-3.500v-5.200c0-1.300 0-2.800-1.800-2.800s-2 1.300-2 2.700V20H10z' },
]

export function Footer() {
  return (
    <footer className="border-t border-line">
      <div className="container-x grid gap-10 py-14 md:grid-cols-12">
        <div className="md:col-span-5">
          <Wordmark className="text-4xl" />
          <p className="mt-4 max-w-xs text-muted">Made for the clubs that make college worth it.</p>
        </div>
        <nav aria-label="Footer" className="md:col-span-3">
          <p className="eyebrow mb-4">Explore</p>
          <ul className="space-y-2.5">
            {NAV_LINKS.map((l) => (
              <li key={l.label}>
                <a href={l.href} className="hover:underline hover:decoration-accent hover:decoration-4 hover:underline-offset-4">
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>
        <div className="md:col-span-4">
          <p className="eyebrow mb-4">Say hi</p>
          {/* Placeholder address: replace with your real inbox */}
          <a href="mailto:hello@sorted.example" className="font-display text-xl font-bold tracking-tight [overflow-wrap:anywhere] lg:text-2xl hover:underline hover:decoration-accent hover:decoration-4 hover:underline-offset-4">
            hello@sorted.example
          </a>
          <ul className="mt-5 flex gap-2">
            {SOCIALS.map((s) => (
              <li key={s.label}>
                <a
                  href={s.href}
                  aria-label={s.label}
                  className="flex h-11 w-11 items-center justify-center rounded-full border border-line transition-colors hover:border-accent hover:bg-accent hover:text-[#111]"
                >
                  <svg viewBox="0 0 24 24" className="h-5 w-5" fill={s.label === 'Instagram' ? 'none' : 'currentColor'} stroke={s.label === 'Instagram' ? 'currentColor' : 'none'} strokeWidth="1.6" aria-hidden="true">
                    <path d={s.d} />
                  </svg>
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="container-x border-t border-line py-6 text-sm text-muted">
        &copy; {new Date().getFullYear()} Sorted. All rights reserved.
      </div>
    </footer>
  )
}
