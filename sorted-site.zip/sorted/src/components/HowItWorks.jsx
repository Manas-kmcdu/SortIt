import { useRef } from 'react'
import { motion, useScroll, useSpring, useInView, useReducedMotion } from 'framer-motion'
import { Section, PhotoFrame, cx } from './ui'
import { STEPS } from '../data'

function Step({ s }) {
  const ref = useRef(null)
  const on = useInView(ref, { margin: '-45% 0px -45% 0px', once: true })
  const reduce = useReducedMotion()
  return (
    <li ref={ref} className="relative pl-14 md:pl-20">
      <span
        aria-hidden="true"
        className={cx(
          'absolute left-0 top-1 flex h-9 w-9 items-center justify-center rounded-full border-2 text-xs font-bold transition-all duration-500 md:h-11 md:w-11 md:text-sm',
          on ? 'on-accent scale-100 border-fg bg-accent text-[#111]' : 'scale-90 border-line bg-bg text-muted',
        )}
      >
        {s.n}
      </span>
      <motion.div
        initial={reduce ? false : { opacity: 0.25, y: 12 }}
        animate={on || reduce ? { opacity: 1, y: 0 } : { opacity: 0.25, y: 12 }}
        transition={{ duration: 0.5 }}
      >
        <h3 className="font-display text-3xl font-extrabold leading-[1.05] tracking-tightest md:text-5xl">{s.title}</h3>
        <p className="mt-3 max-w-lg text-lg text-muted">{s.text}</p>
      </motion.div>
    </li>
  )
}

export default function HowItWorks() {
  const ref = useRef(null)
  const reduce = useReducedMotion()
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start 65%', 'end 60%'] })
  const scaleY = useSpring(scrollYProgress, { stiffness: 120, damping: 30, restDelta: 0.001 })

  return (
    <Section
      id="how-it-works"
      eyebrow="How it works"
      title="Four steps. One of them is yours."
      intro="One WhatsApp group is not a logistics system. This is."
      className="border-t border-line"
    >
      <div className="grid gap-12 lg:grid-cols-12">
        <div ref={ref} className="relative lg:col-span-7">
          <div aria-hidden="true" className="absolute bottom-0 left-[17px] top-2 w-px bg-line md:left-[21px]" />
          <motion.div
            aria-hidden="true"
            style={{ scaleY: reduce ? 1 : scaleY, transformOrigin: 'top' }}
            className="absolute bottom-0 left-[16px] top-2 w-[3px] rounded-full bg-fg md:left-[20px]"
          />
          <ol className="space-y-20 md:space-y-28">
            {STEPS.map((s) => (
              <Step key={s.n} s={s} />
            ))}
          </ol>
        </div>
        <div className="hidden lg:col-span-5 lg:block">
          <div className="sticky top-28">
            <PhotoFrame label="On-ground crew, setup day" ratio="aspect-[4/5]" />
          </div>
        </div>
      </div>
    </Section>
  )
}
