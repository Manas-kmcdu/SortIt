import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Button, Arrow, cx } from './ui'
import { NAV_LINKS } from '../data'

export function Wordmark({ className }) {
  return (
    <span className={cx('font-display font-extrabold tracking-tightest', className)}>
      sorted<span className="text-accent">.</span>
    </span>
  )
}

function ThemeToggle({ theme, onToggle }) {
  const dark = theme === 'dark'
  return (
    <button
      onClick={onToggle}
      aria-label={dark ? 'Switch to light mode' : 'Switch to dark mode'}
      className="flex h-10 w-10 items-center justify-center rounded-full border border-line transition-colors hover:border-accent hover:bg-accent hover:text-[#111]"
    >
      {dark ? (
        <svg viewBox="0 0 20 20" className="h-[18px] w-[18px]" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" aria-hidden="true">
          <circle cx="10" cy="10" r="3.5" />
          <path d="M10 2.5v2M10 15.5v2M2.5 10h2M15.5 10h2M4.7 4.7l1.4 1.4M13.9 13.9l1.4 1.4M4.7 15.3l1.4-1.4M13.9 6.1l1.4-1.4" />
        </svg>
      ) : (
        <svg viewBox="0 0 20 20" className="h-[18px] w-[18px]" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <path d="M16.5 11.5A6.5 6.5 0 018.5 3.5a6.5 6.5 0 108 8z" />
        </svg>
      )}
    </button>
  )
}

export default function Nav({ theme, onToggleTheme }) {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    if (!open) return
    const onKey = (e) => e.key === 'Escape' && setOpen(false)
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open])

  return (
    <header className="fixed inset-x-0 top-0 z-50 px-3 sm:px-4">
      <div
        className={cx(
          'mx-auto flex items-center justify-between gap-4 transition-all duration-500 ease-out',
          scrolled
            ? 'mt-2 max-w-[1100px] rounded-full border border-line bg-bg/75 px-4 py-2 backdrop-blur-xl sm:px-5'
            : 'mt-0 max-w-[1280px] rounded-full border border-transparent px-1 py-5 sm:px-3',
        )}
      >
        <a href="#top" aria-label="Sorted, home" className="rounded-full px-1">
          <Wordmark className={cx('transition-all duration-500', scrolled ? 'text-2xl' : 'text-3xl')} />
        </a>

        <nav aria-label="Primary" className="hidden items-center gap-1 md:flex">
          {NAV_LINKS.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="rounded-full px-4 py-2 text-[15px] font-medium text-muted transition-colors hover:bg-fg/5 hover:text-fg"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <ThemeToggle theme={theme} onToggle={onToggleTheme} />
          <Button href="#quote" className={cx('hidden sm:inline-flex', scrolled ? 'px-5 py-2.5' : '')}>
            Get Sorted <Arrow />
          </Button>
          <button
            className="flex h-10 w-10 items-center justify-center rounded-full border border-line md:hidden"
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
            aria-controls="mobile-menu"
            onClick={() => setOpen((o) => !o)}
          >
            <svg viewBox="0 0 20 20" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true">
              {open ? <path d="M5 5l10 10M15 5L5 15" /> : <path d="M3 6h14M3 14h14" />}
            </svg>
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="mx-auto mt-2 max-w-[1100px] rounded-3xl border border-line bg-bg/95 p-3 backdrop-blur-xl md:hidden"
          >
            <nav aria-label="Mobile">
              <ul>
                {NAV_LINKS.map((l) => (
                  <li key={l.label}>
                    <a
                      href={l.href}
                      onClick={() => setOpen(false)}
                      className="block rounded-2xl px-4 py-3.5 font-display text-2xl font-bold tracking-tight hover:bg-fg/5"
                    >
                      {l.label}
                    </a>
                  </li>
                ))}
              </ul>
              <Button href="#quote" onClick={() => setOpen(false)} className="mt-2 w-full" magnetic={false}>
                Get Sorted <Arrow />
              </Button>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  )
}
