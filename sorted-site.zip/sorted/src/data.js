// All copy lives here so it is easy to edit.
// Anything marked SAMPLE is placeholder content: replace with real figures and quotes before launch.
export const SAMPLE_COPY = true

export const NAV_LINKS = [
  { label: 'Merch', href: '#what-we-do' },
  { label: 'Events', href: '#what-we-do' },
  { label: 'How it works', href: '#how-it-works' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'FAQ', href: '#faq' },
]

export const NEEDS = [
  { id: 'merch', label: 'Merch' },
  { id: 'events', label: 'Event' },
  { id: 'both', label: 'Both' },
]

export const FEATURED = {
  merch: {
    line: 'Tees, hoodies and ID cards, designed with you and delivered to your door.',
    items: ['Custom tees', 'Hoodies', 'ID cards', 'Tote bags', 'Stationery'],
  },
  events: {
    line: 'Venue, permissions, sound, security and crew. One checklist, zero chasing.',
    items: ['Venue & permissions', 'Sound, lights, stage', 'Ticketing', 'On-ground crew'],
  },
  both: {
    line: 'Merch for the fest, logistics for the fest. One quote, one point of contact.',
    items: ['Fest merch drop', 'Stage & sound', 'Printing', 'Photography'],
  },
}

export const CLUBS = [
  'Music Society',
  'Dramatics',
  'Debate',
  'Photography',
  'E-Cell',
  'Dance',
  'Quiz Club',
  'NSS',
  'Coding Club',
]

// SAMPLE figures
export const STATS = [
  { value: 120, suffix: '+', label: 'clubs sorted' },
  { value: 400, suffix: '+', label: 'events delivered' },
  { value: 25, suffix: 'k+', label: 'merch pieces shipped' },
]

export const PILLARS = {
  merch: {
    id: 'merch',
    tag: 'Merch',
    title: 'Merch that looks like you meant it.',
    text: 'From first sketch to doorstep. We handle design, printing, quality checks and delivery.',
    list: ['Custom tees', 'Hoodies', 'ID cards', 'Tote bags', 'Stationery'],
    perks: ['Design help', 'Low minimums', 'Bulk pricing', 'Doorstep delivery'],
    photo: 'Merch drop, hoodies on the steps',
  },
  events: {
    id: 'events',
    tag: 'Events',
    title: 'Events without the 2 a.m. panic.',
    text: 'From first poster to last chair stacked, we handle it. You focus on the show.',
    list: [
      'Venue & permissions',
      'Vendors',
      'Sound, lights, stage',
      'Security',
      'Ticketing',
      'Printing',
      'Photography',
      'On-ground crew',
    ],
    perks: ['Permission support', 'Vetted vendors', 'Day-of crew', 'Post-event report'],
    photo: 'Fest stage setup, golden hour',
  },
}

export const STEPS = [
  {
    n: '01',
    title: 'Tell us what you need',
    text: 'Merch, a fest, a one-day event. A two-minute brief is enough. No 40-message thread.',
  },
  {
    n: '02',
    title: 'Get a quote in 24 hrs',
    text: 'Vendor quotes side by side, already negotiated. You approve with one tap.',
  },
  {
    n: '03',
    title: 'We execute',
    text: 'Permissions, production, crew, deliveries. We chase the vendors so you never have to.',
  },
  {
    n: '04',
    title: 'You take the credit',
    text: 'You get the applause. Your college gets a tidy report. Everyone wins.',
  },
]

// SAMPLE case studies
export const CASES = [
  {
    tag: 'Fest',
    title: 'Fest in 7 days',
    text: 'A cultural fest that was stuck at "we have a date" a week out.',
    photo: 'Main stage, night two',
    stats: [
      { label: 'Vendors to chase', before: '14', after: '1' },
      { label: 'Planning time', before: '3 wks', after: '7 days' },
    ],
  },
  {
    tag: 'Merch',
    title: '300 hoodies in 10 days',
    text: 'Society hoodies, sized and delivered before the inter-college meet.',
    photo: 'Hoodie drop, club room',
    stats: [
      { label: 'Turnaround', before: '6 wks', after: '10 days' },
      { label: 'Sizing errors', before: '40+', after: '0' },
    ],
  },
  {
    tag: 'Event',
    title: 'Permissions in 48 hrs',
    text: 'A debate championship that needed three sign-offs and a hall.',
    photo: 'Auditorium, set for debate',
    stats: [
      { label: 'Approval time', before: '9 days', after: '48 hrs' },
      { label: 'Follow-up calls', before: '25', after: '3' },
    ],
  },
  {
    tag: 'Budget',
    title: 'Zero budget surprises',
    text: 'A tech fest that finished on the number it started with.',
    photo: 'Registration desk, day one',
    stats: [
      { label: 'Budget overshoot', before: '+32%', after: '0%' },
      { label: 'Committee payment chase', before: '2 wks', after: '1 day' },
    ],
  },
]

export const TIERS = [
  {
    name: 'Starter',
    blurb: 'One order or one small event. Try us, no strings.',
    price: 'Pay per order',
    features: ['Merch up to 100 pieces', 'Design help', 'Quote in 24 hrs', 'Doorstep delivery'],
  },
  {
    name: 'Club',
    blurb: 'For clubs with a calendar full of things to run.',
    price: 'Per-event pricing',
    featured: true,
    features: [
      'Merch + events, one account',
      'Vendor quote comparison',
      'Budget tracker',
      'Payment splitting',
      'Priority support',
    ],
  },
  {
    name: 'Fest',
    blurb: 'The big one. Multi-day, multi-vendor, multi-everything.',
    price: 'Custom quote',
    features: [
      'Dedicated coordinator',
      'Permissions & security',
      'On-ground crew',
      'Sponsor & college reports',
    ],
  },
]

export const BUDGETS = [
  'Under ₹25,000',
  '₹25,000 – ₹1,00,000',
  '₹1,00,000 – ₹5,00,000',
  '₹5,00,000+',
  'Not sure yet',
]

// SAMPLE quotes: swap for real ones (with permission) before launch
export const TESTIMONIALS = [
  {
    quote: 'I used to run a fest from eleven WhatsApp groups. Now it is one dashboard and a lot more sleep.',
    name: 'Name Surname',
    role: 'President, Dramatics Society',
    college: 'College Name',
  },
  {
    quote: 'The hoodies arrived before the meet. Every size was right. I still cannot believe it.',
    name: 'Name Surname',
    role: 'Head, Music Society',
    college: 'College Name',
  },
  {
    quote: 'Our principal asked for a post-event report. We sent it in ten minutes. Legend status unlocked.',
    name: 'Name Surname',
    role: 'Secretary, E-Cell',
    college: 'College Name',
  },
]

// SAMPLE policies: confirm each answer before launch
export const FAQS = [
  {
    q: 'How fast can you turn things around?',
    a: 'Quotes land within 24 hours. Merch usually ships in 7 to 14 days depending on the item and quantity. Events depend on your date, so tell us early and we will tell you straight.',
  },
  {
    q: 'What is the minimum order?',
    a: 'Low on purpose. Most merch starts at around 25 pieces, and we will flag it if something needs more to make sense.',
  },
  {
    q: 'How do payments work?',
    a: 'Pay online by UPI or card. You can split the amount across your committee, so nobody fronts the whole thing and nobody chases anyone for money.',
  },
  {
    q: 'Which cities do you cover?',
    a: 'We are starting with major college hubs and growing. Fill in the form with your college and we will confirm coverage in your quote.',
  },
  {
    q: 'What is your refund policy?',
    a: 'If we miss what we promised, we fix it or refund it. Custom-printed merch cannot be returned once production starts, and we will always show you a proof first.',
  },
]
