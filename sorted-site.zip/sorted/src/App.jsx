import { useCallback, useState } from 'react'
import Nav from './components/Nav'
import Hero from './components/Hero'
import Proof from './components/Proof'
import Pillars from './components/Pillars'
import HowItWorks from './components/HowItWorks'
import Bento from './components/Bento'
import Showcase from './components/Showcase'
import Pricing from './components/Pricing'
import Testimonials from './components/Testimonials'
import Faq from './components/Faq'
import { FinalCTA, Footer } from './components/Closing'

export default function App() {
  const [theme, setTheme] = useState(() => document.documentElement.getAttribute('data-theme') || 'light')
  const [need, setNeed] = useState('both')
  const [presetNeed, setPresetNeed] = useState('')

  const toggleTheme = useCallback(() => {
    setTheme((t) => {
      const next = t === 'dark' ? 'light' : 'dark'
      document.documentElement.setAttribute('data-theme', next)
      try {
        localStorage.setItem('sorted-theme', next)
      } catch (e) {
        /* storage can be blocked: the toggle still works for this visit */
      }
      return next
    })
  }, [])

  const onCta = (n) => setPresetNeed(n)
  const onNeedChange = (n) => {
    setNeed(n)
    setPresetNeed(n)
  }

  return (
    <>
      <a
        href="#main"
        className="on-accent sr-only z-[60] rounded-full bg-accent px-5 py-3 font-semibold text-[#111] focus:not-sr-only focus:fixed focus:left-4 focus:top-4"
      >
        Skip to content
      </a>
      <Nav theme={theme} onToggleTheme={toggleTheme} />
      <main id="main">
        <Hero need={need} onNeedChange={onNeedChange} onCta={onCta} />
        <Proof />
        <Pillars need={need} />
        <HowItWorks />
        <Bento />
        <Showcase />
        <Pricing presetNeed={presetNeed} />
        <Testimonials />
        <Faq />
        <FinalCTA />
      </main>
      <Footer />
    </>
  )
}
